function tau = studentController(t, s, model, params)
% Modify this code to calculate the joint torques
% t - time
% s - state of the robot
% model - struct containing robot properties
% params - user defined parameters in studentParams.m
% tau - 10x1 vector of joint torques

% State vector components ID
q = s(1 : model.n);
dq = s(model.n+1 : 2*model.n);

t
% 
% % [Control #1] zero control
% tau = zeros(10,1);
% 
% return

%% [Control #2] High Gain Joint PD control on all actuated joints
% kp = 531 ;
% kd = 150 ;
% x0 = getInitialState(model);
% q0 = x0(1:model.n) ;
% tau = -kp*(q(model.actuated_idx)-q0(model.actuated_idx)) - kd*dq(model.actuated_idx) ;
% 
% return

%% [Control #3] UMich controller for moving forward
% x0 = getInitialState(model);
% q0 = x0(1:model.n) ;
% [r_com_des] = computeComPosVel(q0, 0*q0, model);
% 
% [r_com, v_com] = computeComPosVel(q, dq, model);
% 
% % left hip abduction 
% kp1 = 80 ; 
% kd1 = 4 ; 
% 
% % right hip abduction 
% kp2 = 80 ; 
% kd2 = 4 ; 
% 
% % left hip rotation
% kp3 = 40 ; 
% kd3 = 4 ; 
% 
% % right hip rotation
% kp4 = 40 ; 
% kd4 = 4 ; 
% 
% % left hip flexion
% kp5 = 200 ;
% kd5 = 10 ;
% 
% % right hip flexion
% kp6 = 200 ;
% kd6 = 10 ;
% 
% % left knee joint 
% kp7 = 400*10 ; 
% kd7 = 20*5 ; 
% 
% % right knee joint
% kp8 = 400*10 ; 
% kd8 = 20*5 ;  
% 
% %hip - y direction
% tau_1 = -kp1*(-r_com(2)  + q(7) - q0(7)) - kd1*(-v_com(2) + dq(7));
% tau_2 = -kp2*(-r_com(2) + q(8) - q0(8)) - kd2*(-v_com(2) + dq(8));
% 
% 
% tau_3 = -kp3*(q(9)-q0(9)) - kd3*dq(9) ;
% tau_4 = -kp4*(q(10)-q0(10)) - kd4*dq(10) ;
% 
% tau_5 = -kp5*(q(11)-q0(11)) - kd5*dq(11) ;
% tau_6 = -kp6*(q(12)-q0(12)) - kd6*dq(12) ;
% 
% % knee - z direction
% tau_7 = -kp7*(r_com(3) + q(13) - q0(13) - r_com_des(3)) - kd7*(v_com(3) + dq(13));
% tau_8 = -kp8*(r_com(3) + q(14) - q0(14)- r_com_des(3)) - kd8*(v_com(3) + dq(14));
% 
% % -0.8894 - 0.115
% % feet - x direction
% % tau_9 = -200*2*(r_com(1) - (-0.0) - s(49)) - 20*2*(v_com(1)); % 0.02,200
% % tau_10 = -200*2*(r_com(1) - (-0.0) - s(49)) - 20*2*(v_com(1));
% 
% tau_9 = -200*2*(r_com(1) - (-0.0) - s(49)) - 20*2*(v_com(1)-s(51)*cos(s(53))); % 0.02,200
% tau_10 = -200*2*(r_com(1) - (-0.0) - s(49)) - 20*2*(v_com(1)-s(51)*cos(s(53)));
% 
% tau = [tau_1 tau_2 tau_3 tau_4 tau_5 tau_6 tau_7 tau_8 tau_9 tau_10]';


%% [Control #4] UMich controller for moving sideway - simple case
% x0 = getInitialState(model);
% q0 = x0(1:model.n) ;
% [r_com_des] = computeComPosVel(q0, 0*q0, model);
% 
% [r_com, v_com] = computeComPosVel(q, dq, model); % inertial frame
% 
% % left hip abduction 
% kp1 = 80 ; 
% kd1 = 4 ; 
% 
% % right hip abduction 
% kp2 = 80 ; 
% kd2 = 4 ; 
% 
% % left hip rotation
% kp3 = 40 ; 
% kd3 = 4 ; 
% 
% % right hip rotation
% kp4 = 40 ; 
% kd4 = 4 ; 
% 
% % left hip flexion
% kp5 = 200 ;
% kd5 = 10 ;
% 
% % right hip flexion
% kp6 = 200 ;
% kd6 = 10 ;
% 
% % left knee joint 
% kp7 = 400*10 ; 
% kd7 = 20*5 ; 
% 
% % right knee joint
% kp8 = 400*10 ; 
% kd8 = 20*5 ;  
% 
% % hip - y direction (body frame)
% tau_1 = -kp1*(r_com(1)  + q(7) - q0(7)) - kd1*(-v_com(1) + dq(7));
% tau_2 = -kp2*(r_com(1) + q(8) - q0(8)) - kd2*(-v_com(1) + dq(8));
% 
% 
% tau_3 = -kp3*(q(9)-q0(9)) - kd3*dq(9) ;
% tau_4 = -kp4*(q(10)-q0(10)) - kd4*dq(10) ;
% 
% tau_5 = -kp5*(q(11)-q0(11)) - kd5*dq(11) ;
% tau_6 = -kp6*(q(12)-q0(12)) - kd6*dq(12) ;
% 
% % knee - z direction
% tau_7 = -kp7*(r_com(3) + q(13) - q0(13) - r_com_des(3)) - kd7*(v_com(3) + dq(13));
% tau_8 = -kp8*(r_com(3) + q(14) - q0(14)- r_com_des(3)) - kd8*(v_com(3) + dq(14));
% 
% % feet - x direction (body frame)
% tau_9 = -200*2*(r_com(2) - (-0.0) - s(50)) - 20*2*(v_com(2)); % 0.02,200
% tau_10 = -200*2*(r_com(2) - (-0.0) - s(50)) - 20*2*(v_com(2));
% 
% tau = [tau_1 tau_2 tau_3 tau_4 tau_5 tau_6 tau_7 tau_8 tau_9 tau_10]';


%% [Control #5] UMich controller for moving sideway - general case
x0 = getInitialState(model);
q0 = x0(1:model.n) ;

% Hovershoe states: 57 ~ 63
x = s(2*model.n+17);
y = s(2*model.n+18);
v = s(2*model.n+19);
theta = s(2*model.n+20);
psi = s(2*model.n+21);
dtheta = s(2*model.n+22);
dpsi = s(2*model.n+23);

% pitch transformation matrix
g_pitch = theta;
trans_pitch = rot_y(g_pitch);

% yaw transformation
g_yaw = psi;
trans_yaw = rot_z(g_yaw);

% z
g_z = 0.115;
trans_offset = [x; y; g_z];

[r_com_des_ini] = computeComPosVel(q0, 0*q0, model) + [0;0;0];
r_com_des = trans_pitch' * trans_yaw' * r_com_des_ini;

[r_com_ini, v_com_ini] = computeComPosVel(q, dq, model); % inertial frame
r_com = trans_pitch' * trans_yaw' * (r_com_ini - trans_offset);
v_com = trans_pitch' * trans_yaw' * v_com_ini;

% s_trans = trans_pitch' * trans_yaw' * [s(49) s(50) g_z]';
% 
% s(49) = s_trans(1);

% left hip abduction 
kp1 = 80 ; 
kd1 = 4 ; 

% right hip abduction 
kp2 = 80 ; 
kd2 = 4 ; 

% left hip rotation
kp3 = 40 ; 
kd3 = 4 ; 

% right hip rotation
kp4 = 40 ; 
kd4 = 4 ; 

% left hip flexion
kp5 = 200 ;
kd5 = 10 ;

% right hip flexion
kp6 = 200 ;
kd6 = 10 ;

% left knee joint 
kp7 = 400*10 ; 
kd7 = 20*5 ; 

% right knee joint
kp8 = 400*10 ; 
kd8 = 20*5 ;  

% hip - y direction (body frame)
tau_1 = -kp1*(-r_com(2)  + q(7) - q0(7)) - kd1*(-v_com(2) + dq(7));
tau_2 = -kp2*(-r_com(2) + q(8) - q0(8)) - kd2*(-v_com(2) + dq(8));


tau_3 = -kp3*(q(9)-q0(9)) - kd3*dq(9) ;
tau_4 = -kp4*(q(10)-q0(10)) - kd4*dq(10) ;

tau_5 = -kp5*(q(11)-q0(11)) - kd5*dq(11) ;
tau_6 = -kp6*(q(12)-q0(12)) - kd6*dq(12) ;

% knee - z direction
tau_7 = -kp7*(r_com(3) + q(13) - q0(13) - r_com_des(3)) - kd7*(v_com(3) + dq(13));
tau_8 = -kp8*(r_com(3) + q(14) - q0(14)- r_com_des(3)) - kd8*(v_com(3) + dq(14));

% % feet - x direction (body frame)
% tau_9 = -200*2*(r_com(1) - (-0.0) ) - 20*2*(v_com(1)); % 0.02,200
% tau_10 = -200*2*(r_com(1) - (-0.0) ) - 20*2*(v_com(1));

if t>.1
    % feet - x direction (body frame)
    tau_9 = -200*2*(r_com(1) - (-0.0) ) - 20*2*(v_com(1)); % 0.02,200
    tau_10 = -200*2*(r_com(1) - (-0.0) ) - 20*2*(v_com(1));
else
    tau_9 = 0;
    tau_10 = 0;
end

tau = [tau_1 tau_2 tau_3 tau_4 tau_5 tau_6 tau_7 tau_8 tau_9 tau_10]';
% tau = [tau_1 tau_2 tau_3 tau_4 tau_5 tau_6 tau_7 tau_8 0 0]';


