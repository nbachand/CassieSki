function Jcom = computeComJacobian(q, model)

Jcom=COMJac_vel(model, q) ;