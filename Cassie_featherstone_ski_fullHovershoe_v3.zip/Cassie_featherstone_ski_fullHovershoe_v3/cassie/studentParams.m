function params = studentParams(model)
% define any parameters here 
% params - struct

params = struct();

% theta dynamics
params.Jtheta = 30 ; % 10
wn = 25*2 ; % natural frequency = sqrt(k/m) = sqrt(c1/Jtheta) [https://en.wikipedia.org/wiki/Damping_ratio]
zeta = 1 ; % daming ratio = c / cc = c2 / (2*sqrt(c1*Jtheta))
params.c1 = wn^2 * params.Jtheta ;
params.c2 = zeta * 2 * sqrt(params.c1*params.Jtheta) ;

% psi dynamics
params.Jpsi = 0.01 ; 
params.c3 = 40 ;

% x-y dynamics
params.m = 1 ;
params.c4 = 25*5;