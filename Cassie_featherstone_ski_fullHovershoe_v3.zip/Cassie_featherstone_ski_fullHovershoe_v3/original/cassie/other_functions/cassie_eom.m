function [xdot, tau, u_theta, u_psi] = cassie_eom(t, s, model, params, externalForce)
% t: time
% s: state
% model: cassie model
% params: control parameters
% externalForce: user defined disturbance

%% State vector components ID

% Cassie states: 1 ~ 40
q = s(1 : model.n); % extract state q
dq = s(model.n+1 : 2*model.n); % extract state dq

% Ground states: 41 ~ 48

% Hovershoe states: 49 ~ 55
x = s(2*model.n+9);
y = s(2*model.n+10);
v = s(2*model.n+11);
theta = s(2*model.n+12);
psi = s(2*model.n+13);
dtheta = s(2*model.n+14);
dpsi = s(2*model.n+15);

%% Student Control input
% get STUDENT Control: 10 actuated joints (10-by-1)
tauStudent = studentController(t, s, model, params);
% adding torque saturation
tauMax = repmat([25*4.5; 25*4.5; 16*12.2; 16*12.2; 50*0.9], 2, 1);  % maximum joint torque
tauStudent = min(max(tauStudent, -tauMax), tauMax);                 % applied torque after saturation check
% Some pre-processing of the torques before we simulate
tau  = zeros(20,1);
tau(model.actuated_idx) = tauStudent;

%% ----------------------------External forces-------------------------------
% -------------------------------------------------------------------------
% f_ext{i} must either be an empty array, indicating
% that there is no external force acting on body i, or else a spatial or
% planar vector (as appropriate) giving the external force expressed in
% absolute coordinates.
f_ext = externalForce(t, q, model);

%% ----------------------------Dynamics-------------------------------------
% -------------------------------------------------------------------------
% ground contact model
K = 1e6 ;
D = 2000 ;
mu = 0.8 ;

% ground contact states 2-by-4
gc_d = reshape(s((2*model.n+1) : (2*model.n + 2*length(model.gc.body))), 2, length(model.gc.body)) ;

% calculate positions and velocities of contact points
posvel = gcPosVel(model, q, dq) ;   % 6-by-4, [pos; vel]

% pitch transformation matrix
g_pitch = theta;
trans_pitch = rot_y(g_pitch);

% yaw transformation
g_yaw = psi;
trans_yaw = rot_z(g_yaw);

% translational transformation matrix
g_x = x;
g_y = y;
g_z = 0.115;
trans_offset = [g_x g_x g_x g_x; g_y g_y g_y g_y; g_z g_z g_z g_z];

% Coordinate transformation
% posvel_1 = trans_yaw * trans_pitch * (posvel(1:3,:) - trans_offset);
% posvel_2 = trans_yaw * trans_pitch * posvel(4:6,:) - trans_yaw * trans_pitch * [v*cos(psi);v*sin(psi);0];
posvel_1 = trans_pitch * trans_yaw * (posvel(1:3,:) - trans_offset);
posvel_2 = trans_pitch * trans_yaw * posvel(4:6,:) - trans_pitch * trans_yaw * [v*cos(psi);v*sin(psi);0];

% Calculate 2D/3D ground reaction forces due to compliant contact
[fp, gc_dd, ~] = gcontact( K, D, mu, posvel_1, posvel_2, gc_d) ;

f = Fpt(fp, posvel_1) ;
u_theta = -(f(2,1)+f(2,3)+f(2,2)+f(2,4));
u_psi = -(f(3,1)+f(3,3)+f(3,2)+f(3,4));

% convert forces at points to equivalent spatial forces
% fp = trans_pitch' * trans_yaw' *  fp;
fp = trans_yaw' * trans_pitch' *  fp;

% Calculate forces at contact points in inertial frame
f = Fpt(fp, posvel(1:3,:)) ;
%f = Fpt(fp, posvel_1) ;

% f_c = trans_yaw * f(1:3,:);


% relative_distance_left_xy = sqrt((posvel_1(1,1)+posvel_1(1,2))/2,(posvel_1(2,1)+posvel_1(2,2))/2);
% relative_distance_left = sqrt(relative_distance_left_xy,(posvel_1(3,1)+posvel_1(3,2))/2);
% relative_distance_right_xy = sqrt((posvel_1(1,3)+posvel_1(1,4))/2,(posvel_1(2,3)+posvel_1(2,4))/2);
% relative_distance_right = sqrt(relative_distance_right_xy,(posvel_1(3,1)+posvel_1(3,2))/2);
% add_f_c = cross(relative_distance, f_c)

% Hovershoe input
% u_theta = -(f_c(2,1)+f_c(2,3)+f_c(2,2)+f_c(2,4));
% u_psi = -(f(3,1)+f(3,3)+f(3,2)+f(3,4));
%u_theta = -(f_c(2,1)+f_c(2,2));
%u_psi = -(f(3,1)+f(3,2));

% compute accelerations
ddq = gcFD_pert(model, @FDgq, [q; dq; tau; reshape(f, 6*length(model.gc.body), 1)],f_ext) ;

% state derivative
dCassie = [dq; 
        ddq; 
        reshape(gc_dd, 2*length(model.gc.body), 1)] ;
    
% Hovershoe model
dHovershoe = [v*cos(psi);
    v*sin(psi);
    (params.c4/params.m)*theta;
    dtheta;
    dpsi;
    (1/params.Jtheta)*( -params.c1*theta - params.c2*dtheta + u_theta );
    (1/params.Jpsi)*( -params.c3*dpsi + u_psi );
    ] ;

xdot = [dCassie; dHovershoe];

end