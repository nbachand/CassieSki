% function run_cassie()
clc
close all ;

% add paths
startup;

% Load Cassie model and set Initial configuration
load('cassie_hovershoe_model.mat') ;

% Initial configuration: 62-by-1
x0 = getInitialState(model);

% Get STUDENT Control Parameters
params = studentParams(model);

% Cassie ODE options 
time_inter = [0 20] ;
odeopts = odeset('Events', @falldetect);
externalForce_fun = @ExternalForce ;

%% Simulation 
% disp('Simulating...') ;
tic
[t_vec, x_vec] = ode15s( @cassie_eom, time_inter, x0, odeopts, model, params, externalForce_fun) ;
toc
% t_vec: N-by-1
% x_vec: N-by-62
disp(['Simulated for ' num2str(t_vec(end)), 's'])

%% Calculate score
score = calcScore(t_vec', x_vec', model);
disp(['Score: ', num2str(score)])

%% Visualize
% Animation
% 3D model animation:
stateData = getVisualizerState(x_vec, model);
vis = CassieVisualizer(t_vec, stateData);

%% Hovershoe Plots
% Plot hovershoe position
figure ;
    plot(t_vec, x_vec(:,57)); hold on; 
    plot(t_vec, x_vec(:,58)); hold on;
    plot(t_vec, x_vec(:,64)); hold on; 
    plot(t_vec, x_vec(:,65)); hold on; 
    title('Hovershoe position');
    legend('left-x-hovershoe', 'left-y-hovershoe', 'right-x-hovershoe', 'right-y-hovershoe');
    
% Plot hovershoe theta and psi
figure ;
    plot(t_vec, x_vec(:,60)*180/pi); hold on; 
    plot(t_vec, x_vec(:,67)*180/pi); hold on;
    title('Hovershoe theta');
    ylabel('deg') ; xlabel('Time (s)') ;
    legend('left-theta-hovershoe','right-theta-hovershoe');
    
figure ;
    plot(t_vec, x_vec(:,61)*180/pi); hold on;
    plot(t_vec, x_vec(:,68)*180/pi); hold on;
    title('Hovershoe psi');
    ylabel('deg') ; xlabel('Time (s)') ;
    legend('left-psi-hovershoe', 'right-psi-hovershoe');
    
% Plot hovershoe velocity
figure ;
    plot(t_vec, x_vec(:,59)); hold on;
    plot(t_vec, x_vec(:,66)); hold on;
    title('Hovershoe Velocity');
    legend('left-hovershoe-vel','right-hovershoe-vel');

return

%% COM sequence
r_com = zeros(length(t_vec), 3) ;           % N-by-3
foot_p = zeros(length(t_vec), 4, 3) ;       % foot position: N-by-4-by-3
for i = 1 : size(x_vec,1)
    r_com(i,:) = compute_COM_pos(model, x_vec(i,1:model.NB))' ;
    [foot_p1, foot_p2, foot_p3, foot_p4] = computeFootPositions(x_vec(i,1:model.NB), model);
    foot_p(j,1,:) = foot_p1; 
    foot_p(j,2,:) = foot_p2;
    foot_p(j,3,:) = foot_p3;
    foot_p(j,4,:) = foot_p4;
end

%% Plots and animation



disp('Graphing...') ;

% Plot COM position, base orientation, joint angles
% figure() ; 
%     subplot(3,1,1);plot(t_vec, r_com) ;grid ; title('com positions x-y-z') ;hold; legend('x','y','z') ;
%     subplot(3,1,2); plot(t_vec, x_vec(:,4:6)) ; grid ; title('base angles') ; 
%     subplot(3,1,3); plot(t_vec, x_vec(:,7:model.n)) ; grid ; title('joint angles') ; 


% figure() ; 
%     plot(t_vec, r_com) ;grid ; title('com positions x-y-z') ;hold; legend('x','y','z') ;
% 
% figure() ; 
%     plot(t_vec, r_com - 0.5*([foot_p(:,1,1) foot_p(:,1,2) foot_p(:,1,3)]+[foot_p(:,2,1) foot_p(:,2,2) foot_p(:,2,3)])) ;grid ; title('com positions x-y-z') ;hold; legend('x','y','z') ;

figure() ; 
    plot(t_vec, r_com(:,1) - x_vec(:,49)) ;grid ; title('com X positions wrt hovershoe') ;

    
% Plot Base (Pelvis) Position
% figure ; plot(t_vec, x_vec(:,1:3)) ; grid on ;
%     title('Base (Pelvis) Translation') ; legend('x','y','z') ;

% % Plot Base (Pelvis) Orientation
% figure ; plot(t_vec, x_vec(:,4:6)*180/pi) ; grid on ;
%     title('Base (Pelvis) Orientation') ; legend('r','p','y') ;
    
% % Plot Torques
% figure ; 
%     subplot(2,1,1) ;
%         plot(t_vec, tau_vec(:, [model.jidx.hip_abduction_left; model.jidx.hip_rotation_left; model.jidx.hip_flexion_left; model.jidx.knee_joint_left; model.jidx.toe_joint_left])) ;
%         grid on ; title('Left Torques') ; legend('abduction','rotation','flexion','knee','toe') ;
%     subplot(2,1,2) ;
%         plot(t_vec, tau_vec(:, [model.jidx.hip_abduction_right; model.jidx.hip_rotation_right; model.jidx.hip_flexion_right; model.jidx.knee_joint_right; model.jidx.toe_joint_right])) ;
%         grid on ; title('Right Torques') ; legend('abduction','rotation','flexion','knee','toe') ;

% Plot toe pitch sequences
% figure ;
%     plot(t_vec, x_vec(:,[19,20])); grid on; title('toe pitch');
%     legend('left toe pitch', 'right toe pitch');
%     
% % % Plot foot position sequences
% figure ;
%     plot(t_vec, foot_p(:,1,3),'k--'); hold on; 
%     plot(t_vec, foot_p(:,2,3),'b'); hold on;
%     plot(t_vec, foot_p(:,3,3),'r--'); hold on;
%     plot(t_vec, foot_p(:,4,3),'m'); hold on;
%     legend('left tiptoe', 'left heel', 'right tiptoe', 'right heel');
%     

%% Calculate control signals and contact point positions
% disp('Computing control signals...') ;
xdot_vec = zeros(size(x_vec)) ;             % dx: N-by-70
tau_vec = zeros(length(t_vec), 20) ;        % tau: N-by-20
u_theta_vec = zeros(length(t_vec), 1) ;
u_psi_vec = zeros(length(t_vec), 1) ;
for j=1:length(t_vec)
    % compute state evolution
    [xdot_,tau_,u_theta_,u_psi_] = cassie_eom(t_vec(j),x_vec(j,:)', model, params, externalForce_fun) ;
    xdot_vec(j,:) = xdot_' ;
    tau_vec(j,:) = tau_' ;
    u_theta_vec(j) = u_theta_ ;
    u_psi_vec(j) = u_psi_ ;
end

figure ; plot(t_vec, u_theta_vec, t_vec, u_psi_vec) ;
    grid on ; xlabel('Time (s)') ; ylabel('Nm') ; legend('u-theta','u-psi') ;
