function x0 = getInitialState(model)

% 70 states in total
% 1 ~ NB: cassie position state
% NB+1 ~ 2*NB: cassie velocity state
% 2*NB+1 ~ 2*NB+8: ground model 1 for left hovershoe
% 2*NB+9 ~ 2*NB+16: ground model 2 for right hovershoe
% 2*NB+17 ~ 2*NB+23: left hovershoe model
% 2*NB+24 ~ 2*NB+30: right hovershoe model

x0 = zeros(2*model.NB+30,1);

% Actuated joints initialization
% model.jidx: model joint index
x0(model.jidx.hip_abduction_left) = 0 ;     % state: 7
x0(model.jidx.hip_rotation_left) = 0 ;      % state: 9
x0(model.jidx.hip_flexion_left) = 0.5 ;     % state: 11
x0(model.jidx.knee_joint_left) = -1.2 ;     % state: 13
x0(model.jidx.toe_joint_left) = -1.6 ;      % state: 19

x0(model.jidx.hip_abduction_right) = 0 ;    % state: 8
x0(model.jidx.hip_rotation_right) = 0 ;     % state: 10
x0(model.jidx.hip_flexion_right) = 0.5 ;    % state: 12
x0(model.jidx.knee_joint_right) = -1.2 ;    % state: 14
x0(model.jidx.toe_joint_right) = -1.6 ;     % state: 20

% Impose constraints
x0(model.jidx.ankle_joint_left) = deg2rad(13) - x0(model.jidx.knee_joint_left) ;    % state: 17  
x0(model.jidx.ankle_joint_right) = deg2rad(13) - x0(model.jidx.knee_joint_right) ;  % state: 18

% correction for z, state: 3
ground_pos = X_to_r(bodypos(model, model.idx.foot1, x0)) ;
x0(3) = -ground_pos(3) ;

% correction for feet angles
foot_pos = gcPosVel(model, x0, 0*x0) ;
foot_pos_min = min(foot_pos(3,:)) ;
foot_pos_max = max(foot_pos(3,:)) ;
x0(3) = x0(3) - foot_pos_min ;

% Initialisation for two ground models
x0(41:48) = 0 ;
x0(49:56) = 0 ;

% Adding z-axis offset
x0(3) = x0(3) + 0.115;

% Initialization for hovershoe
% Moving sideway
% x0 = x0 + [zeros(56,1); 0; 0; 0; 0; pi/2; 0; 0;...
%     0; 0; 0; 0; pi/2; 0; 0];
% x0(6) = pi/2;

% Moving 30 degree
% x0 = x0 + [zeros(56,1); 0; 0; 0; 0; pi/6; 0; 0; ...
%     0; 0; 0; 0; pi/6; 0; 0];
% x0(6) = pi/6;

% Moving forward
x0 = x0 + [zeros(56,1); 0; 0; 0; 0; 0; 0; 0; ...
    0; 0; 0; 0; 0; 0; 0];
x0(6) = 0;


end