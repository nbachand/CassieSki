function [xdot, tau] = cassie_eom(t, s, model, params, externalForce)
% t: time
% s: state
% model: cassie model
% params: control parameters
% externalForce: user defined disturbance

%% -------------------State vector components ID---------------------------

% Cassie states: 1 ~ 40
q = s(1 : model.n);             % extract state q
dq = s(model.n+1 : 2*model.n);  % extract state dq

% Get foot position
% [p1, p2, p3, p4] = computeFootPositions(q, model)

% Ground states: 41 ~ 48; 49 ~ 56

% Left hovershoe states: 57 ~ 63
x_l =      s(2*model.n+17);
y_l =      s(2*model.n+18);
v_l =      s(2*model.n+19);
theta_l =  s(2*model.n+20);
psi_l =    s(2*model.n+21);
dtheta_l = s(2*model.n+22);
dpsi_l =   s(2*model.n+23);

% Right hovershoe states: 64 ~ 70
x_r =      s(2*model.n+24);
y_r =      s(2*model.n+25);
v_r =      s(2*model.n+26);
theta_r =  s(2*model.n+27);
psi_r =    s(2*model.n+28);
dtheta_r = s(2*model.n+29);
dpsi_r =   s(2*model.n+30);

%% -------------------------Student Control input--------------------------
% get STUDENT Control: 10 actuated joints (10-by-1)
tauStudent = studentController(t, s, model, params);
% adding torque saturation
tauMax = repmat([25*4.5; 25*4.5; 16*12.2; 16*12.2; 50*0.9], 2, 1);  % maximum joint torque
tauStudent = min(max(tauStudent, -tauMax), tauMax);                 % applied torque after saturation check
% some pre-processing of the torques before we simulate
tau  = zeros(20,1);
tau(model.actuated_idx) = tauStudent;

%% ----------------------------External forces-----------------------------
% f_ext{i} must either be an empty array, indicating
% that there is no external force acting on body i, or else a spatial or
% planar vector (as appropriate) giving the external force expressed in
% absolute coordinates.
f_ext = externalForce(t, q, model);

%% ----------------------------Dynamics------------------------------------
% Ground contact model
K = 1e6 ;
D = 2000 ;
mu = 0.8 ;

% Ground contact 1 states 2-by-4: for the left hovershoe
% Ground contact 2 states 2-by-4: for the right hovershoe
% We create two grounds for two hovershoes that are at the origin
gc_d_1 = reshape(s(41 : 48), 2, length(model.gc.body)) ;
gc_d_2 = reshape(s(49 : 56), 2, length(model.gc.body)) ;

% Calculate positions and velocities of contact points 
posvel = gcPosVel(model, q, dq) ;   % 6-by-4, [pos; vel]

% Pitch transformation matrix
g_pitch_l = theta_l;                % 1-by-1
trans_pitch_l = rot_y(g_pitch_l);   % 3-by-3
g_pitch_r = theta_r;                % 1-by-1
trans_pitch_r = rot_y(g_pitch_r);   % 3-by-3

% Yaw transformation matrix
g_yaw_l = psi_l;                    % 1-by-1
trans_yaw_l = rot_z(g_yaw_l);       % 3-by-3
g_yaw_r = psi_r;                    % 1-by-1
trans_yaw_r = rot_z(g_yaw_r);       % 3-by-3

% Translational transformation matrix
g_x_l = x_l;
g_y_l = y_l;
g_x_r = x_r;
g_y_r = y_r;
g_z = 0.115;
trans_offset_l = [g_x_l g_x_l; g_y_l g_y_l; g_z g_z]; % 3-by-2
trans_offset_r = [g_x_r g_x_r; g_y_r g_y_r; g_z g_z]; % 3-by-2
% trans_offset = [g_x_l g_x_l g_x_r g_x_r; g_y_l g_y_l g_y_r g_y_r; g_z g_z g_z g_z];

% Coordinate transformation: inertial frame to body frame
% 1: left tiptoe
% 2: left heel
% 3: right tiptoe
% 4: right heel
posvel_1_l = trans_pitch_l * trans_yaw_l * (posvel(1:3,1:2) - trans_offset_l);                                                    % 3-by-2
posvel_2_l = trans_pitch_l * trans_yaw_l * posvel(4:6,1:2) - trans_pitch_l * trans_yaw_l * [v_l*cos(psi_l); v_l*sin(psi_l); 0];   % 3-by-2

posvel_1_r = trans_pitch_r * trans_yaw_r * (posvel(1:3,3:4) - trans_offset_r);                                                    % 3-by-2
posvel_2_r = trans_pitch_r * trans_yaw_r * posvel(4:6,3:4) - trans_pitch_r * trans_yaw_r * [v_r*cos(psi_r); v_r*sin(psi_r); 0];   % 3-by-2

% posvel_1 = [posvel_1_l, posvel_1_r];        % 3-by-4
% posvel_2 = [posvel_2_l, posvel_2_r];        % 3-by-4

% Calculate ground reaction forces due to compliant contact: body frame
[fp_1, gc_dd_1, ~] = gcontact( K, D, mu, posvel_1_l, posvel_2_l, gc_d_1) ;
[fp_2, gc_dd_2, ~] = gcontact( K, D, mu, posvel_1_r, posvel_2_r, gc_d_2) ;

% Compute forces at contact points in the body frame
f_1 = Fpt(fp_1, posvel_1_l) ;         % 6-by-2: [torque; force]
f_2 = Fpt(fp_2, posvel_1_r) ;         % 6-by-2: [torque; force]

% Calculate hovershoe input in the body frame
u_theta_l = .25*(f_1(6,1)-f_1(6,2));
u_psi_l   = .25*(f_1(5,1)-f_1(5,2));

u_theta_r = .25*(f_2(6,1)-f_2(6,2));
u_psi_r   = .25*(f_2(5,1)-f_2(5,2));

% Coordinate transformation: body frame to inertial frame
fp_l = trans_yaw_l' * trans_pitch_l' *  fp_1;
fp_r = trans_yaw_r' * trans_pitch_r' *  fp_2;
fp = [fp_l, fp_r];

% Calculate forces at contact points in inertial frame
% posvel(1:3,:) is in the inertial frame
f = Fpt(fp, posvel(1:3,:)) ; % 6-by-4

% compute accelerations in inertial frame
ddq = gcFD_pert(model, @FDgq, [q; dq; tau; reshape(f, 6*length(model.gc.body), 1)],f_ext) ;

% State derivative
dCassie = [dq; 
        ddq; 
        reshape(gc_dd_1, 2*length(model.gc.body), 1);
        reshape(gc_dd_2, 2*length(model.gc.body), 1);] ;
    
% Hovershoe model
dHovershoe = [v_l*cos(psi_l);
    v_l*sin(psi_l);
    (params.c4/params.m)*theta_l;
    dtheta_l;
    dpsi_l;
    (1/params.Jtheta)*( -params.c1*theta_l - params.c2*dtheta_l + u_theta_l );
    (1/params.Jpsi)*( -params.c3*dpsi_l + u_psi_l );
    v_r*cos(psi_r);
    v_r*sin(psi_r);
    (params.c4/params.m)*theta_r;
    dtheta_r;
    dpsi_r;
    (1/params.Jtheta)*( -params.c1*theta_r - params.c2*dtheta_r + u_theta_r );
    (1/params.Jpsi)*( -params.c3*dpsi_r + u_psi_r );
    ] ;

xdot = [dCassie; dHovershoe];

end